package com.example.hospital_mgmt;

public class patientUserDetails {

    static String name = "";
    static String chatWith = "";
}