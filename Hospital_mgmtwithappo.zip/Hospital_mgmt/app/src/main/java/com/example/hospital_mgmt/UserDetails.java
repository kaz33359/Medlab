package com.example.hospital_mgmt;

public class UserDetails {
        static String name = "";
        static String chatWith = "";
}
