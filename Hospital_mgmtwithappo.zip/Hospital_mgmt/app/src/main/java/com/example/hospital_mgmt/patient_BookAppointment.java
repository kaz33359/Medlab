package com.example.hospital_mgmt;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class patient_BookAppointment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient__book_appointment);
    }
}
