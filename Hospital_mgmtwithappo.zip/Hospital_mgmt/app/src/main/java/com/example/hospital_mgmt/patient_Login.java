package com.example.hospital_mgmt;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class patient_Login extends Activity implements View.OnClickListener {

    private Button patientLogin_Btn;
    private EditText patientEmail_Et , patientPassword_Et;
    private TextView patientSignup_Tv;

    private ProgressDialog progressDialog;

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient__login);

        progressDialog = new ProgressDialog(this);

        firebaseAuth = FirebaseAuth.getInstance();

        if (firebaseAuth.getCurrentUser() != null){
            //profile activity

            finish();
            startActivity(new Intent (getApplicationContext(), patient_Dashboard.class));
        }

        patientLogin_Btn = (Button) findViewById(R.id.patientlogin_btn);
        patientEmail_Et = (EditText) findViewById(R.id.patientemail_et);
        patientPassword_Et = (EditText) findViewById(R.id.patientpassword_et);
        patientSignup_Tv= (TextView) findViewById(R.id.patientsignup_tv);
        patientLogin_Btn.setOnClickListener(this);
        patientSignup_Tv.setOnClickListener(this);
    }

    public void doctorLogin()
    {
        String email = patientEmail_Et.getText().toString().trim();
        String pass = patientPassword_Et.getText().toString().trim();

        if(TextUtils.isEmpty(email))
        {
            //email is empty
            Toast.makeText(this, "Enter an email id", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(pass))
        {
            //pass is empty
            Toast.makeText(this,"Enter Password",Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.setMessage("Registering...");
        progressDialog.show();


        firebaseAuth.signInWithEmailAndPassword(email,pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressDialog.dismiss();

                        if (task.isSuccessful())
                        {
                            //start profile activiy
                            finish();
                            startActivity(new Intent(getApplicationContext(), patient_Dashboard.class));
                        }
                    }
                });

    }

    @Override
    public void onClick(View v) {

        if (v == patientLogin_Btn)
        {
            doctorLogin();
        }
        if (v == patientSignup_Tv)
        {
            finish();
            startActivity(new Intent(this, patient_Registration.class));
        }

    }
}



