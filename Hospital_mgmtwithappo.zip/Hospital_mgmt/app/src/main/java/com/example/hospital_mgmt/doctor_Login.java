package com.example.hospital_mgmt;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class doctor_Login extends Activity implements View.OnClickListener {

    private Button doctorLogin_Btn;
    private EditText doctorEmail_Et , doctorPassword_Et;
    private TextView doctorSignup_Tv;

    private ProgressDialog progressDialog;

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor__login);

        progressDialog = new ProgressDialog(this);

        firebaseAuth = FirebaseAuth.getInstance();

        if (firebaseAuth.getCurrentUser() != null){
            //profile activity

            finish();
            startActivity(new Intent (getApplicationContext(), doctor_Dashboard.class));
        }

        doctorLogin_Btn = (Button) findViewById(R.id.doctorlogin_btn);
        doctorEmail_Et = (EditText) findViewById(R.id.doctoremail_et);
        doctorPassword_Et = (EditText) findViewById(R.id.doctorpassword_et);
        doctorSignup_Tv= (TextView) findViewById(R.id.doctorsignup_tv);

        doctorLogin_Btn.setOnClickListener(this);
        doctorSignup_Tv.setOnClickListener(this);
    }

    public void doctorLogin()
    {
        String email = doctorEmail_Et.getText().toString().trim();
        String pass = doctorPassword_Et.getText().toString().trim();

        if(TextUtils.isEmpty(email))
        {
            //email is empty
            Toast.makeText(this, "Enter an email id", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(pass))
        {
            //pass is empty
            Toast.makeText(this,"Enter Password",Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.setMessage("Registering...");
        progressDialog.show();


        firebaseAuth.signInWithEmailAndPassword(email,pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressDialog.dismiss();

                        if (task.isSuccessful())
                        {
                            //start profile activiy
                            finish();
                            startActivity(new Intent(getApplicationContext(), doctor_Dashboard.class));
                        }
                    }
                });

    }

    @Override
    public void onClick(View v) {

        if (v == doctorLogin_Btn)
        {
            doctorLogin();
        }
        if (v == doctorSignup_Tv)
        {
            finish();
            startActivity(new Intent(this, doctor_Registration.class));
        }

    }
}



