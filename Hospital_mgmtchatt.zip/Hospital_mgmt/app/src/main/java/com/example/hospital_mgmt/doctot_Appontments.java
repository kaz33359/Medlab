package com.example.hospital_mgmt;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class doctot_Appontments extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctot__appontments);
    }
}
